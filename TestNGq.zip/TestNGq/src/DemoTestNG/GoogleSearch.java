package DemoTestNG;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class GoogleSearch {
	File path = new File("C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe");
	FirefoxBinary fb = new FirefoxBinary(path);
	FirefoxProfile ffp = new FirefoxProfile();
	WebDriver driver = new FirefoxDriver(fb, ffp);

	@BeforeSuite
	public void InvokeApplication() throws InterruptedException {
		System.out.println("Before Suite");
		driver.get("http://www.google.com/");
		Thread.sleep(3000);
	}

	@BeforeTest
	public void maxBrowWindow() {
		System.out.println("Before Test");
		driver.manage().window().maximize();
	}

	@Test(enabled = true)
	public void TC1_searchGoogle() {
		driver.findElement(By.xpath("//input[@title='Search']")).sendKeys("Download Selenium");
	}

	@Test(dependsOnMethods = { "TC1_searchGoogle" }, enabled = true)
	public void TC2_printSearchResults() throws InterruptedException {
		Thread.sleep(3000);
		int no = driver.findElements(By.xpath("//ul[@class='sbsb_b']//li")).size();
		for (int i = 1; i <= no; i++)
			System.out.println(driver.findElement(By.xpath("//ul[@class='sbsb_b']//li[" + i + "]/div/div[2]")).getText());
	}

	@Test(enabled = true)
	public void TC3_clickSearch() {
		driver.findElement(By.xpath("//button[@value='Search']")).click();
	}

	@AfterTest
	public void closeDriverInstance() {
		System.out.println("After Test");
		driver.quit();
	}

	@AfterSuite
	public void afterSuite() {
		System.out.println("After Suite");
	}
}
