package DemoTestNG;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Annotations {

	@BeforeSuite
	public void b4Suite() {
		System.out.println("BEFORE SIUITE");
	}

	@BeforeTest
	public void b4Test() {
		System.out.println("BEFORE TEST");
	}

	@BeforeClass
	public void b4Class() {
		System.out.println("BEFORE CLASS");
	}

	@BeforeMethod
	public void b4Method() {
		System.out.println("BEFORE METHOD");
	}

	@Test
	public void test1() {
		System.out.println("TEST 1");
	}

	@Test
	public void test2() {
		System.out.println("TEST 2");
	}

	@Test
	public void test3() {
		System.out.println("TEST 3");
	}

	@Test
	public void test4() {
		System.out.println("TEST 4");
	}

	@AfterMethod
	public void afterMethod() {
		System.out.println("AFTER METHOD");
	}

	@AfterClass
	public void afterClass() {
		System.out.println("AFTER CLASS");
	}

	@AfterTest
	public void afterTest() {
		System.out.println("AFTER TEST");
	}

	@AfterSuite
	public void afterSuite() {
		System.out.println("AFTER SIUITE");
	}
}
