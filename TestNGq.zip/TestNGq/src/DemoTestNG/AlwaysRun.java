package DemoTestNG;

import org.testng.annotations.Test;

public class AlwaysRun {

	@Test
	public void test1() {
		int a = 10;
		int b = a / 0;
	}

	@Test(dependsOnMethods = { "test1" },alwaysRun=false)
	public void test2() {
		System.out.println("Always Run");
	}
} 
