package DemoTestNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class TimeOutPerformance {

	@Test(timeOut = 200)
	public void LoadPageIn200() {
		WebDriver driver = new FirefoxDriver();
		driver.get("http://demo.nopecommerce.com");
	}
}
