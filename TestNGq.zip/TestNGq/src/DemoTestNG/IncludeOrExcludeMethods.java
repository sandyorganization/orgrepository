package DemoTestNG;

import org.testng.annotations.Test;

public class IncludeOrExcludeMethods {

	@Test
	public void InclTest1() {
		System.out.println("Include this test -1");
	}

	@Test
	public void InclTest2() {
		System.out.println("Include this test -2");
	}

	@Test
	public void ExclTest1() {
		System.out.println("Exclude this test -1");
	}

	@Test
	public void InclTest3() {
		System.out.println("Include this test -3");
	}

}
