package DemoTestNG;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class PassParameters {

	@Test
	@Parameters({ "userID", "password" })
	public void testParam(String usrID, String pwd) {
		System.out.println(usrID + " " + pwd);
	}

	@Test
	@Parameters({ "message", "suitelevel" })
	public void PrintMessage(String msg, String suitelevel) {
		System.out.println(msg);
		System.out.println("Printed Suite Level Parameter in this test" + ":" + suitelevel);
	}

}
