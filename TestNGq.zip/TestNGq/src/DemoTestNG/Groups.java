package DemoTestNG;

import org.testng.annotations.Test;

public class Groups {

	@Test(groups = { "priority1" })
	public void test1() {
		System.out.println("test1 - priority1");
	}

	@Test
	public void test2() {
		System.out.println("test2");
	}

	@Test(groups = { "priority1" })
	public void test3() {
		System.out.println("test3 - priority1");
	}

	@Test
	public void test4() {
		System.out.println("test4");
	}

	@Test(groups = { "priority1" })
	public void test5() {
		System.out.println("test5- priority1");
	}
}
