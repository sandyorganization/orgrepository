package DemoTestNG;

import org.testng.annotations.Test;

public class DisableEnableTests {

	@Test(enabled = false)
	public void DisTest1() {
		System.out.println("Disabled");
	}

	@Test(enabled = false)
	public void DisTest2() {
		System.out.println("Disabled");
	}

	@Test
	public void EnabTest1() {
		System.out.println("Enabled");
	}

	@Test(enabled = false)
	public void EnabTest2() {
		System.out.println("Enabled");
	}
}
