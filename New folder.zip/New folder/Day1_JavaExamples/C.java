package Day1_JavaExamples;

class C extends P
{
	public void m2() {
	}

}
