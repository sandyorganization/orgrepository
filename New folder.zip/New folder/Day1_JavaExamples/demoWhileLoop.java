package Day1_JavaExamples;

public class demoWhileLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 10, j = 15;
		while (i <= j) {
			System.out.println(i + "\n");
			i++;
		}
	}
}
