package DAy3_Examples;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class Parameterization {

	/**
	 * @param args
	 * @throws InterruptedException 
	 */
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
//		WebDriver driver = new FirefoxDriver();
		System.setProperty("webdriver.chrome.driver","H:\\chrome driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://demo.nopcommerce.com");
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("(//a[contains(text(),'Computers')])[1]"))).build().perform();
		driver.findElement(By.xpath("(//a[contains(text(),'Notebooks')])[1]")).click();
		Thread.sleep(2000);
		int notebookscount = driver.findElements(By.xpath("//h1[text()='Notebooks']/parent::div/following-sibling::div/div[3]/div/div")).size();
		for (int i = 1; i <= notebookscount; i++) {
			String text = driver.findElement(By.xpath("//h1[text()='Notebooks']/parent::div/following-sibling::div/div[3]/div/div[" + i + "]/div/div[2]//h2/a")).getText();
			if (text.contains("book")) {
				driver.findElement(By.xpath("//h1[text()='Notebooks']/parent::div/following-sibling::div/div[3]/div/div[" + i + "]/div/div[2]//input[@value='Add to cart']")).click();
			}
		}
		driver.findElement(By.xpath("//a[contains(text(),'shopping cart')]")).click();
		
	}
}
