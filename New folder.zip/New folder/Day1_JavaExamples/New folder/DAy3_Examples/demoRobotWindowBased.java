package DAy3_Examples;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class demoRobotWindowBased {

	/**
	 * @param args
	 * @throws AWTException
	 * @throws InterruptedException
	 */
	public static void main(String[] args) throws AWTException, InterruptedException {
//		WebDriver driver = new FirefoxDriver();
		System.setProperty("webdriver.chrome.driver","H:\\chrome driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);

		try {
			driver.get("https://onecognizant.cognizant.com/");
		} catch (Exception e) {
			System.out.println(e);
		}

		Thread.sleep(2000);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_2);
		robot.keyPress(KeyEvent.VK_5);
		robot.keyPress(KeyEvent.VK_4);
		robot.keyPress(KeyEvent.VK_5);
		robot.keyPress(KeyEvent.VK_7);
		robot.keyPress(KeyEvent.VK_3);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyPress(KeyEvent.VK_S);
		robot.keyPress(KeyEvent.VK_W);
		robot.keyPress(KeyEvent.VK_A);
		robot.keyPress(KeyEvent.VK_T);
		robot.keyPress(KeyEvent.VK_H);
		robot.keyPress(KeyEvent.VK_I);
		robot.keyPress(KeyEvent.VK_ENTER);
		driver.manage().timeouts().pageLoadTimeout(120, TimeUnit.SECONDS);

	}

}
