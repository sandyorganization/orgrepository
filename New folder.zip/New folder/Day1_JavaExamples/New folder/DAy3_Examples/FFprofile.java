package DAy3_Examples;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;

public class FFprofile {

	public static void main(String[] args) throws IOException {

		String fb = "D:\\Other Supp Files\\firebug-2.0.13-fx.xpi";
		String fp = "D:\\Other Supp Files\\firepath-0.9.7.1-fx.xpi";
		FirefoxProfile ffp = new FirefoxProfile();
		ffp.addExtension(new File(fb));
		ffp.addExtension(new File(fp));
		File fl = new File("C:\\Program Files\\Mozilla Firefox\\firefox.exe");
		FirefoxBinary ffb = new FirefoxBinary(fl);
		WebDriver driver = new FirefoxDriver(ffb, ffp);
		driver.get("http://www.gmail.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//		driver.findElement(By.linkText("Sign in")).click();
//		WebDriverWait wt = new WebDriverWait(driver, 90);
//		wt.until(ExpectedConditions.visibilityOf(driver.findElement(By.name("Email"))));
		driver.findElement(By.name("Email")).sendKeys("swathi.samyuktha");
		driver.findElement(By.name("signIn")).click();
		driver.findElement(By.name("Passwd")).sendKeys("sam1234");
		driver.findElement(By.id("signIn")).click();
		driver.quit();
	}

}
