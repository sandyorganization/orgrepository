package DAy3_Examples;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class demoMultiWindowAndFrameHdfc {

	public static void main(String[] args) throws InterruptedException {

		WebDriver driver = new FirefoxDriver();

		driver.get("http://www.hdfcbank.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		try {
			if (driver.findElement(By.xpath("//img[@alt='Close'and @src='/assets/images/close.png']")).isDisplayed())
				driver.findElement(By.xpath("//img[@alt='Close'and @src='/assets/images/close.png']")).click();
		} catch (Exception e) {
			System.out.println("Element not displayed" + " " + e);
		}
		driver.findElement(By.xpath("//img[@id='loginsubmit' and @src='/assets/images/newhompageimages/btn-login.gif']")).click();

		for (String winhandle : driver.getWindowHandles()) {
			if (driver.switchTo().window(winhandle).getTitle().equals("HDFC Bank NetBanking - Internet Banking Services by HDFC Bank")) {
				driver.switchTo().window(winhandle);
				Thread.sleep(2000);
				driver.manage().window().maximize();
				driver.findElement(By.xpath("//img[@border='none']")).click();
				driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
				// System.out.println(driver.getTitle());
				driver.switchTo().frame("login_page");
				driver.findElement(By.xpath("//input[@class='input_password']")).sendKeys("122422");
				driver.switchTo().defaultContent();
			}
		}
		driver.quit();
	}
}
