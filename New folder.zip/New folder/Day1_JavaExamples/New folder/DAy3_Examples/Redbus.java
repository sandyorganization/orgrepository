package DAy3_Examples;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Redbus {

	private static final int ColNum = 0;
	private static final int RowNum = 0;

	public static String main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","H:\\chrome driver\\chromedriver.exe");
		WebDriver d1 = new ChromeDriver();
		d1.get("https://www.redbus.in/");
		d1.findElement(By.id("src")).sendKeys "Goa";
		 Sheet s;
//		    WebDriver driver = new FirefoxDriver();
		    FileInputStream fi = new FileInputStream("H:\\Data_excel.xls");
//		    Workbook W = Workbook.getWorkbook(fi);
		    XSSFWorkbook ExcelWorkbook = new XSSFWorkbook(fi);
            s= (Sheet) ExcelWorkbook.getSheetAt(0);
            XSSFSheet ExcelWSheet = ExcelWorkbook.getSheet("Sheet1");
            XSSFCell Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
            
  			String CellData = Cell.getStringCellValue();

  			return CellData;
	}
		    
	}


