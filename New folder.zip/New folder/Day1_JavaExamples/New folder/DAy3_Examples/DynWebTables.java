package DAy3_Examples;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class DynWebTables {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new FirefoxDriver();
		driver.get("https://www.jobserve.com/in/en/Candidate/Login.aspx?url=B855B22C0C5A8D885CD970A744BD76C5089B17047462804EC53F");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.id("PolicyOptInLink")).click();
		driver.findElement(By.xpath(".//*[@id='txbEmail']")).sendKeys("swathi.samyuktha@gmail.com");
		driver.findElement(By.xpath(".//*[@id='txbPassword']")).sendKeys("samson@1234");
		driver.findElement(By.xpath(".//*[@id='btnlogin']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(".//*[@id='txtKey']")).sendKeys("manager");
		// driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		driver.findElement(By.xpath(".//*[@id='btnSearch']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(".//*[@id='searchtogglelink']")).click();
		// clicking all links with manager
		Thread.sleep(1000);
		int count = driver.findElements(By.xpath("//a[@class='jobListPosition']")).size();
		for (int i = 1; i <= count; i++) {
			if (driver.findElement(By.xpath("//div[@class='joblistingcollection']/div[1]/div[" + i + "]/div[1]/a[1]")).getText().contains("India")) {
				driver.findElement(By.xpath("//div[@class='joblistingcollection']/div[1]/div[" + i + "]/div[1]/a")).click();
				driver.navigate().back();
			}
		}
		driver.close();
	}
}

