package DAy3_Examples;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;

public class FFPopupOne {

	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {

		// Firefox Binaries are present in Selenium-Server-Standalone jar and that why the error "Failed to connect to firefox binary"
		
		File pathToBinary = new File("C:\\Program Files\\Mozilla Firefox\\firefox.exe");
		FirefoxBinary fb = new FirefoxBinary(pathToBinary);
		final String firebugPath = "C:\\Other Supp Files\\firebug-2.0.13-fx.xpi";
		final String firepathPath = "C:\\Other Supp Files\\firepath-0.9.7.1-fx.xpi";
		FirefoxProfile profile = new FirefoxProfile();
		profile.addExtension(new File(firebugPath));
		profile.addExtension(new File(firepathPath));
		profile.setPreference("some.preference", true);
		profile.setPreference("network.http.phishy-userpass-length", 255);
		profile.setPreference("network.automatic-ntlm-auth.trusteduris", "onecognizant.cognizant.com");
		WebDriver driver = null;
		driver = new FirefoxDriver(fb, profile);
		driver.get("https://254573:Samyuktha*1234@onecognizant.cognizant.com");

	}

}
