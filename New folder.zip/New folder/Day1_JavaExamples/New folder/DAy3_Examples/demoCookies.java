package DAy3_Examples;


import java.util.Set;

import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class demoCookies {

	public static void main(String[] args) {
//		WebDriver driver = new FirefoxDriver();
		System.setProperty("webdriver.chrome.driver","H:\\chrome driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.msn.com");
		Set<Cookie> cookies = driver.manage().getCookies();
		int cookiesize = driver.manage().getCookies().size();
		System.out.println("No of cookies are" + cookiesize);
		for (Cookie cookie : cookies) {
			System.out.println(cookie.getName() + cookie.getValue());
			// delete current cookie
			driver.manage().deleteCookie(cookie);
			// deletes a specific cookie
			driver.manage().deleteCookieNamed("mh");
		}
		// deletes all the cookies
		driver.manage().deleteAllCookies();
	}
}

