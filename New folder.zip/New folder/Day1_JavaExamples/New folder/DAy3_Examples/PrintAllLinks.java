package DAy3_Examples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class PrintAllLinks {

	/**
	 * @param args
	 * @throws InterruptedException
	 */
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
//		WebDriver driver = new FirefoxDriver();
		System.setProperty("webdriver.chrome.driver","H:\\chrome driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.ebay.com");
		Thread.sleep(4000);
		driver.manage().window().maximize();

		// USING LIST

		// List<WebElement> links = driver.findElements(By.tagName("a"));
		// int linksCount = links.size();
		// System.out.println("The no of links in the page are" + linksCount);
		// String[] linksIntoStr = new String[linksCount];
		// String[] linkNamesIntoStr = new String[linksCount];
		//
		// for (int i = 0; i < links.size(); i++) {
		// linksIntoStr[i] = links.get(i).getAttribute("href");
		// linkNamesIntoStr[i] = links.get(i).getText();
		// System.out.println(linksIntoStr[i] + " == " + linkNamesIntoStr[i]);
		// }

		// USING FOR LOOP

		for (int i = 0; i < driver.findElements(By.tagName("a")).size(); i++) {
			System.out.println(driver.findElements(By.tagName("a")).get(0).getText());
		}
	}
}
