package DAy3_Examples;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class FileDownloadPopupUsingRobot {

	/**
	 * @param args
	 * @throws InterruptedException
	 * @throws AWTException
	 */
	public static void main(String[] args) throws InterruptedException,
			AWTException {
		// TODO Auto-generated method stub
//		WebDriver driver = new FirefoxDriver();
		System.setProperty("webdriver.chrome.driver","H:\\chrome driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.seleniumhq.org/download/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(
				By.xpath("//h3[contains(text(),'Selenium Standalone Server')]/parent::Div/p[3]//a"))
				.click();
		Thread.sleep(4000);
		Robot rb = new Robot();
		rb.keyPress(KeyEvent.VK_SHIFT);
		rb.keyPress(KeyEvent.VK_TAB);
		rb.keyRelease(KeyEvent.VK_TAB);
		rb.keyRelease(KeyEvent.VK_SHIFT);
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
	}
}
