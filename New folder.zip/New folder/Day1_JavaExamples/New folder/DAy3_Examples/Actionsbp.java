package DAy3_Examples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class Actionsbp {

	/**
	 * @param args
	 * @throws InterruptedException
	 */
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
//		WebDriver driver = new FirefoxDriver();
		System.setProperty("webdriver.chrome.driver","H:\\chrome driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.espncricinfo.com");
		Thread.sleep(4000);
		driver.manage().window().maximize();
		Actions act = new Actions(driver);
		driver.findElement(By.xpath("//img[contains(@src,'googlesyndication')]")).click();
		act.moveToElement(driver.findElement(By.xpath("//a[text()='Live Scores']"))).build().perform();
		driver.findElement(By.linkText("//a[text()='Live Scores Home']")).click();

	}

}
