package DAy3_Examples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class testCanvasHTML5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.theautomatedtester.co.uk/demo1.html");
		WebElement canvas = driver.findElement(By.id("tutorial"));
		Actions action = new Actions(driver);
		action.clickAndHold(canvas).moveByOffset(10, 50).moveByOffset(50, 10)
				.moveByOffset(-10, -50).moveByOffset(-50, -10).release()
				.perform();
		driver.close();
	}

}
