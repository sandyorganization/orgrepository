package DAy3_Examples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class childwind {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "H:\\chrome driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		String URL="http://www.seleniummaster.com";   
	     driver.get(URL);  
	     driver.manage().window().maximize(); 
	     driver.findElement(By.xpath("//img[@alt='SeleniumMasterLogo']")).click();  
	     // Switching from parent window to child window   
	     for (String Child_Window : driver.getWindowHandles())  
	     {  
	     driver.switchTo().window(Child_Window);  
	     // Performing actions on child window  
	     driver.findElement(By.id("dropdown_txt")).click(); 
	     
	     
	}

}
}
