package DAy3_Examples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class ExceptionExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 10;
		try {
			int b = a / 0;
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("After exception");
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.google.com");
		try {
			driver.findElement(By.xpath("dfsgjkdfh")).click();

		} catch (Exception e) {
			System.out.println("Element not found" + e);
		}
		System.out.println("After try catch");
	}
}
