package DAy3_Examples;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/* http://roadtoautomation.blogspot.in/2014/04/road-to-automate-html5-video-with.html
 * 
 */

public class videoHTML5 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.w3.org/2010/05/video/mediaevents.html");
		driver.manage().window().maximize();
		JavascriptExecutor js = (JavascriptExecutor) driver;

		// play video
		js.executeScript("document.getElementById(\"video\").play()");
		Thread.sleep(5000);

		// pause playing video
		js.executeScript("document.getElementById(\"video\").pause()");

		// // check video is paused
		// System.out.println(js
		// .executeScript("document.getElementById(\"video\").paused"));

		js.executeScript("document.getElementById(\"video\").play()");

		// play video from starting
		js.executeScript("document.getElementById(\"video\").currentTime=0");
		Thread.sleep(5000);

		// reload video
		js.executeScript("document.getElementById(\"video\").load()");
		driver.close();
	}

}
