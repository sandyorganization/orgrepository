package DAy3_Examples;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class PrintLinksInFooter {

	/**
	 * @param args
	 * @throws InterruptedException
	 */
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.ebay.com");
		Thread.sleep(4000);
		driver.manage().window().maximize();
		WebElement footer = driver.findElement(By
				.xpath("//div[@class='footer']"));
		List<WebElement> links = footer.findElements(By.tagName("a"));
		int linksCount = links.size();
		System.out.println("The no of links in the page are" + linksCount);
		String[] linksIntoStr = new String[linksCount];
		String[] linkNamesIntoStr = new String[linksCount];

		for (int i = 0; i < links.size(); i++) {
			linksIntoStr[i] = links.get(i).getAttribute("href");
			linkNamesIntoStr[i] = links.get(i).getText();
			System.out.println(linksIntoStr[i] + " == " + linkNamesIntoStr[i]);
		}
	}
}
