package DAy3_Examples;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class PrintMenuItems {

	public static void main(String[] args) {
		menuitems();
	}

	public static void menuitems() {

		WebDriver driver = new FirefoxDriver();
		driver.get("http://demo.nopcommerce.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		int menusize = driver.findElements(By.xpath("//ul[@class='top-menu']/li[2]/ul/li")).size();
		System.out.println("The number of items in the menu is" + " " + menusize);
		WebElement menuname = driver.findElement(By.xpath("//ul[@class='top-menu']/li[2]/a"));
		System.out.println("The menu name is" + " " + menuname.getText());
		Actions action = new Actions(driver);
		action.moveToElement(menuname).build().perform();
		System.out.println("The menu items are" + " ");
		for (int i = 1; i <= menusize; i++) {
			String itemname = driver.findElement(By.xpath("//html/body/div[5]/div[2]//ul/li[2]/ul/li[" + i + "]/a")).getText();
			System.out.println(itemname);
		}

	}
}
