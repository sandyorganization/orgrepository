package DAy3_Examples;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class dragAndDropHTML5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		WebDriver driver = new FirefoxDriver();
		System.setProperty("webdriver.chrome.driver","H:\\chrome driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
		driver.get("http://www.theautomatedtester.co.uk/demo2.html");
		WebElement draggable = driver.findElement(By.className("draggable"));
		WebElement droppable = driver.findElement(By.name("droppable"));
		Actions action = new Actions(driver);
		action.dragAndDrop(draggable, droppable).build().perform();
//		driver.close();
	}

}
