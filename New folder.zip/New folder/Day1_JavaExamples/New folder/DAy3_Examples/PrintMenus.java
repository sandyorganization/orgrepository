package DAy3_Examples;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class PrintMenus {

	public static void main(String[] args) {
		printmenu();
	}

	public static void printmenu() {
		WebDriver driver = new FirefoxDriver();
		driver.get("http://demo.nopcommerce.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		int noofmenus = driver.findElements(By.xpath("//ul[@class='top-menu']/li")).size();
		System.out.println("The total no of Menus in the Home Page are" + " " + noofmenus);
		System.out.println("The Menu Names are:");
		for (int i = 1; i <= noofmenus; i++) {
			System.out.println(driver.findElement(By.xpath("//ul[@class='top-menu']/li[" + i + "]/a[1]")).getText());
		}

	}

}
