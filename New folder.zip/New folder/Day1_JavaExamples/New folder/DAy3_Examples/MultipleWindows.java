package DAy3_Examples;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class MultipleWindows {

	/**
	 * @param args
	 * @throws InterruptedException
	 */
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.hdfcbank.com/");
		driver.manage().window().maximize();
		Thread.sleep(4000);

		try {
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//img[contains(@src,'close.png')]")).click();
		} catch (Exception e) {
			System.out.println("The stupid banner not displayed");
		}
		Thread.sleep(4000);
		driver.findElement(By.xpath("//img[contains(@src,'login_butn.png')]")).click();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		for (String windowhandle : driver.getWindowHandles()) {
			driver.switchTo().window(windowhandle);
			if (driver.getTitle().contains("HDFC Bank NetBanking")) {
				driver.manage().window().maximize();
				driver.findElement(By.xpath("//img[contains(@src,'netbanking_continue_red.gif')]")).click();
				Thread.sleep(4000);
				driver.close();
			}
		}
		driver.quit();
	}
}
