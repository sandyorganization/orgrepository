package DAy3_Examples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class demoTooltip {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		WebDriver driver = new FirefoxDriver();
		System.setProperty("webdriver.chrome.driver","H:\\chrome driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.google.com");
		driver.manage().window().maximize();
		Actions action = new Actions(driver);
		action.moveToElement(
				driver.findElement(By.xpath("//img[contains(@src,'/logos/doodles/2016/2016-doodle-fruit-games-day-14-5645577527230464-hp.gif')]")))
				.build().perform();
		String tooltip = driver.findElement(By.xpath("//img[contains(@alt,'Day 14 of the 2016 Dood')]")).getAttribute("alt");
		System.out.println("Tooltip is" + " " + tooltip);
	}

}
