package DAy3_Examples;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class demoAutoIT {

	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		driver.get("http://toolsqa.com/automation-practice-form/");
		Thread.sleep(3000);
		driver.findElement(By.name("photo")).click();
		Runtime.getRuntime().exec("D:\\fileupload.exe");
		
//		Runtime class allows the script to interface with the environment in which the script is running.
//		getRuntime() get the current runtime associated with this process.
//		exec() methods execute the AutoIT script ( FileUpload.exe ) .
	}

}
