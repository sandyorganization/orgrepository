package DAy3_Examples;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class childWindowHandling {
	@Test
	public void handleWindow() {
//		WebDriver d1 = new FirefoxDriver();
		System.setProperty("webdriver.chrome.driver","H:\\chrome driver\\chromedriver.exe");
		WebDriver d1 = new ChromeDriver();
		d1.get("");
		try {
			d1.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			if (d1.getTitle().equals("Access to this site is blocked"))
				d1.findElement(By.name("ws-quota")).click();
			Thread.sleep(3000);
		} catch (Exception e) {
			System.out.println("Access to this site is blocked page is not displayed" + e);
		}
		d1.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		d1.manage().window().maximize();
		String parentWindow = d1.getWindowHandle();
		Set<String> set1 = d1.getWindowHandles();
		String childWindow = "";
		Iterator<String> it1 = set1.iterator();
		while (it1.hasNext()) {
			childWindow = it1.next();
			if (!parentWindow.equals(childWindow)) {
				System.out.println(d1.switchTo().window(childWindow).getTitle());
				d1.switchTo().window(childWindow);
				d1.close();
			}
		}
		d1.switchTo().window(parentWindow);
	}
}