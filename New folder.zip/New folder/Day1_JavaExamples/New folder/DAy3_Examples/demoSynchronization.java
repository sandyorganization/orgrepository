package DAy3_Examples;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class demoSynchronization {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
//		WebDriver driver = new FirefoxDriver();
		System.setProperty("webdriver.chrome.driver","H:\\chrome driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.google.com");
		driver.manage().window().maximize();

		// Threas.sleep()
		Thread.sleep(9000);

		// IMPLICIT WAIT

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		WebElement myDynamicElement1 = driver.findElement(By.id("myDynamicElement"));
	
		// EXPLICIT WAIT

		WebDriverWait wait = new WebDriverWait(driver, 10);
		WebElement myDynamicElement2 = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("myDynamicElement")));
	}
}
