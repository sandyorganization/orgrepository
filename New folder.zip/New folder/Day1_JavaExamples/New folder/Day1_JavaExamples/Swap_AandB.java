package Day1_JavaExamples;

public class Swap_AandB {

	public static void main(String[] args) {
		Swap_AandB ab = new Swap_AandB();
		int a = 2, b = 3;
		System.out.println(("The numbers are a,b with values" + " " + a + " " + "and" + " " + b));
		ab.swap(a, b);
	}

	public void swap(int a, int b) {
		int c;
		c = a;
		a = b;
		b = c;
		System.out.println("Numbers are now swapped, Values of a and b are" + a + "and" + b);
	}

}
