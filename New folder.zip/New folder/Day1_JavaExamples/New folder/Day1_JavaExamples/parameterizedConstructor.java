package Day1_JavaExamples;

public class parameterizedConstructor {

	private String name;

	public parameterizedConstructor(String str) {
		this.name = str;
		System.out.println("I am inside parameterized constructor.");
		System.out.println("The parameter value is: " + str);
	}

	public static void main(String a[]) {
		parameterizedConstructor mpc = new parameterizedConstructor("Madhu Raj");
	}
}
