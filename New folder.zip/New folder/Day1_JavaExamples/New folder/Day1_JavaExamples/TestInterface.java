package Day1_JavaExamples;

public interface TestInterface {
	public void printValues(int a, int b);

	public void multiply(int a, int b);

	public void minusOne(int a);
}
