package Day1_JavaExamples;

public class PBV_PBR {
	int a, b;

	public static void main(String[] args) {
		PBV_PBR p = new PBV_PBR();
		p.a = 10;
		p.b = 20;
		System.out.println(p.a + " " + p.b);
		swap(p.a, p.b);
		System.out.println(p.a + " " + p.b);
		swapval(p);
		System.out.println(p.a + " " + p.b);
	}

	public static void swap(int a, int b) { // pass by value, Here a and b are
											// having a different memory and p.a
											// and p.b having different memory
		int temp = a;
		a = b;
		b = temp;
		System.out.println("Values of a and b within the PBV method are" + " " + a + " " + b); // Values
																								// swapped
																								// within
																								// the
																								// method,
																								// did
																								// not
																								// return
																								// values
	}

	public static void swapval(PBV_PBR t) { // pass by reference
		int temp = t.a;
		t.a = t.b;
		t.b = temp;
	}
}
