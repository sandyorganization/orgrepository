package Day1_JavaExamples;

class P

{
	public void m1() {
	}
	public void m2() {
	}
}