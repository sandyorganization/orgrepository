package Day1_JavaExamples;

import java.io.*;

import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFWorkbook; 
import org.apache.poi.xssf.usermodel.XSSFSheet; 
import org.apache.poi.ss.usermodel.*;

import java.util.Iterator;

public class ReadCellValueFromExcel {
	@SuppressWarnings("unused")
	public static void main(String[] args) throws Exception {
		FileInputStream input_document = new FileInputStream(new File(
				"C:\\Users\\254573\\Desktop\\Test.xlsx"));
		XSSFWorkbook my_xlsx_workbook = new XSSFWorkbook(input_document);
		XSSFSheet my_worksheet = my_xlsx_workbook.getSheetAt(0);
		Iterator<Row> rowIterator = my_worksheet.iterator();
		String searchStr = "12 Monkeys";
		boolean flag = false;
		while (rowIterator.hasNext()) {
			Row row = rowIterator.next();
			Iterator<Cell> cellIterator = row.cellIterator();
			while (cellIterator.hasNext()&& flag==false) {
				Cell cell = cellIterator.next();
				switch (cell.getCellType()) {
				case Cell.CELL_TYPE_NUMERIC:
//					System.out.println("Numeric Value");
					break;
				case Cell.CELL_TYPE_BOOLEAN:
//					System.out.println("Boolean Value");
					break;
				case Cell.CELL_TYPE_BLANK:
//					System.out.println("Blank Value");
					break;
				case Cell.CELL_TYPE_STRING: {
					XSSFRichTextString richTextString = (XSSFRichTextString) cell
							.getRichStringCellValue();
					if (richTextString.toString().equals(searchStr)) {
						Cell cell1 = cellIterator.next();
						Cell cell2 = cellIterator.next();
						Cell cell3 = cellIterator.next();
						Cell cell4 = cellIterator.next();
						Cell cell5 = cellIterator.next();
						Cell cell6 = cellIterator.next();
						Cell cell7 = cellIterator.next();
						Cell cell8 = cellIterator.next();
						System.out.println(cell8.getStringCellValue());
						flag = true;
					}
					break;
				}
				default:
					System.out.println("Other than String Values");
				}
				System.out.println("");
			}
			input_document.close();
		}
	}
}