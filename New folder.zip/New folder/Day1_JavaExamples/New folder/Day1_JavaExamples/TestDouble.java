package Day1_JavaExamples;

public class TestDouble {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String s1 = "1000012121";
		String s2 = "1000013131";
		if (Double.parseDouble(s1) > Double.parseDouble(s2))
			System.out.println("s1 is larger");
		else
			System.out.println("S2 is larger");

	}
}
