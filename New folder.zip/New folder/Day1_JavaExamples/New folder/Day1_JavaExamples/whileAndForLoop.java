package Day1_JavaExamples;

public class whileAndForLoop {

	public static void main(String[] args) {
		int i = 1, sum = 0;
		System.out.println("The first ten numbers are:");
		while (i <= 10) {
			System.out.println(i);
			i = i + 1;
		}

		for (int j = 1; j <= 10; j++) {
			sum = sum + j;
		}
		System.out.println("Sum of first 10 numbers is" + ":" + sum);
	}
}
