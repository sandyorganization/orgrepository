package Day1_JavaExamples;

public class TwoDarray {

	public static void main(String[] args) {
		int cols, rows;
		int[][] arr = new int[2][3]; // Two Dimensional Array

		arr[0][0] = 11;
		arr[0][1] = 12;
		arr[0][2] = 13;

		arr[1][0] = 21;
		arr[1][1] = 22;
		arr[1][2] = 23;

		rows = arr.length;
		System.out.println("No of rows are" + ":" + rows);
		cols = arr[0].length;
		System.out.println("No of columns are" + ":" + cols);

		System.out.println("The array values are:");
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				System.out.print(arr[i][j] + "  ");
			}
			System.out.println();
		}
	}
}
