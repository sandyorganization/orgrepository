package Day1_JavaExamples;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class XMLReading {
	public static void main(String[] args) {

		try {
			File file = new File("D:\\XMLFile\\SampleXML.xml"); // file location
																// should be
			// specified correctly
			// Prepare XML
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document document = db.parse(file);
			document.getDocumentElement().normalize();
			NodeList node = document.getElementsByTagName("catalog");
			System.out.println("catalog Details");
			System.out.println("________________________________________________");

			// Read XML to get test data

			for (int i = 0; i < node.getLength(); i++) {
				Node currentNode = node.item(i);

				if (currentNode.getNodeType() == Node.ELEMENT_NODE) {

					Element element = (Element) currentNode;
					NodeList firstNameList = element.getElementsByTagName("author");
					Element firstName = (Element) firstNameList.item(0);
					NodeList firstName1 = firstName.getChildNodes();
					String fname = ((Node) firstName1.item(0)).getNodeValue();
					System.out.println("author:" + fname);

					NodeList lastNameList = element.getElementsByTagName("title");
					Element lastName = (Element) lastNameList.item(0);
					NodeList lastName1 = lastName.getChildNodes();
					String lname = ((Node) lastName1.item(0)).getNodeValue();
					System.out.println("title:" + lname);

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
