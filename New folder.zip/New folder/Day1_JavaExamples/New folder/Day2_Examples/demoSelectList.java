package Day2_Examples;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class demoSelectList {
	/**
	 * @param args
	 * @throws InterruptedException
	 */
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		driver.get("http://toolsqa.com/automation-practice-form/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)");
		// driver.findElement(By.id("continents")).click();
		Select sel = new Select(driver.findElement(By.xpath("//select[@id='continents']")));
		// sel.selectByIndex(4); // South America
		// sel.selectByVisibleText("North America");
		List<WebElement> ls = sel.getOptions();
		for (int i = 1; i < ls.size(); i++) {
			System.out.println(ls.get(i).getText());
			if (ls.get(i).getText().equals("Australia")) {
				Thread.sleep(1000);
				ls.get(i).click();
			}
		}
	}
}
