package Day2_Examples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class demoWebElementLocators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		driver.get("http://toolsqa.com/automation-practice-form/");
		driver.manage().window().maximize(); // Maximize the browser window
		driver.findElement(By.id("profession-0")).click(); // Located element
															// using ID
		String str = driver.findElement(By.className("radio")).getText();
		System.out.println(str);
		driver.findElement(By.name("firstname")).sendKeys("First Name");
		driver.findElement(By.linkText("Selenium Automation Hybrid Framework")).click();
		driver.navigate().back();
		driver.findElement(By.partialLinkText("Selenium Automation Hybrid")).click();
		driver.navigate().back();
		int noOflinks = driver.findElements(By.tagName("a")).size();
		System.out.println(noOflinks);
		String text = driver.findElement(By.xpath("//strong[contains(text(),'PERSONAL')]")).getText();
		System.out.println(text);
		driver.findElement(By.cssSelector("input[id='exp-1']")).click();
	}
}
