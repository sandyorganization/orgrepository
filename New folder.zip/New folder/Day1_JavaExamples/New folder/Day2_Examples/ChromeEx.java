package Day2_Examples;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ChromeEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:\\Other Supp Files\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.google.com");
		if (driver.getTitle().equals("Google"))
			System.out.println("OPened Google using Chrome");
		else
			System.out.println("Could not open Google");
		driver.quit();
	}
}
