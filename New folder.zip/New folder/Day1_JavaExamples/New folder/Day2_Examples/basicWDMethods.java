package Day2_Examples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class basicWDMethods {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.google.com"); // opens browser
		driver.manage().window().maximize(); // maximizes the window
		String url = driver.getCurrentUrl();
		if(url.contains("google.co"))
			System.out.println("Correct URL");
		else
			System.out.println("Incorrect URL");
		String title=driver.getTitle();
		System.out.println(title);
		if(title.equals("Google"))
			System.out.println("Title is Google, PASS");
		else
			System.out.println("Title is NOT Google, FAIL");
		
		if(driver.findElement(By.xpath("//div[contains(text(),'Google.co.in offered in: ')]")).isDisplayed())
			System.out.println("Element is displayed");
		else
			System.out.println("Element is not displayed");
		
		if(driver.getPageSource().contains("Google.co.in offered in"))
			System.out.println("Element is displayed");
		else
			System.out.println("Element is not displayed");
		
		driver.findElement(By.linkText("Images")).click();
		Thread.sleep(3000);
		driver.navigate().back();
		driver.navigate().forward();
		driver.close();
//		driver.quit();
		
	}
}

