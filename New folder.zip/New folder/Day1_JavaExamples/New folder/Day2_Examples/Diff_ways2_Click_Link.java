package Day2_Examples;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Diff_ways2_Click_Link {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver", "D:\\Other Supp Files\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.google.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

		// using ENTER
		driver.findElement(By.linkText("Gmail")).sendKeys(Keys.ENTER);
		System.out.println("Clicked link using ENTER");

		driver.get("http://www.google.com");
		driver.manage().window().maximize();

		// Using click() method
		driver.findElement(By.linkText("Gmail")).click();
		System.out.println("Clicked link using click method");

		driver.get("http://www.google.com");
		driver.manage().window().maximize();

		// Using RETURN key
		driver.findElement(By.linkText("Gmail")).sendKeys(Keys.RETURN);
		System.out.println("Clicked link using RETURN Key");

		driver.get("http://www.google.com");
		driver.manage().window().maximize();

		// Using Actions
		Actions action = new Actions(driver);
		WebElement termlink = driver.findElement(By.linkText("Gmail"));
		action.moveToElement(termlink);
		termlink.sendKeys(Keys.ENTER);
		System.out.println("Clicked link using Actions");

		driver.get("http://www.google.com");
		driver.manage().window().maximize();

		// Using Javascript executor
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", driver.findElement(By.linkText("Gmail")));
		System.out.println("Clicked link using Javascript executor");
		driver.close();
	}

}
