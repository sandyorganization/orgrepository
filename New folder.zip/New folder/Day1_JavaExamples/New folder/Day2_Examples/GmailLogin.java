package Day2_Examples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class GmailLogin {

	public static void main(String[] args) {

		Login();
	}

	public static void Login() {
		WebDriver dr1 = new FirefoxDriver();
		dr1.get("http://www.gmail.com");
		dr1.manage().window().maximize();
		WebElement email = dr1.findElement(By.id("Email"));
		email.sendKeys("swathi.samyuktha");
		WebElement pwd = dr1.findElement(By.id("Passwd"));
		pwd.sendKeys("test*1234");
		WebElement login = dr1.findElement(By.name("signIn"));
		login.click();
	}
}
