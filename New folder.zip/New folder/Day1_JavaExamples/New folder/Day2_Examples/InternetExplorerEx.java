package Day2_Examples;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class InternetExplorerEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.ie.driver", "D:\\Other Supp Files\\IEDriverServer.exe");
		WebDriver driver = new InternetExplorerDriver();
		driver.get("http://www.google.com");
		if (driver.getTitle().equals("Google"))
			System.out.println("OPened Google using Internet Explorer");
		else
			System.out.println("Could not open Google");
		driver.quit();
	}
}
