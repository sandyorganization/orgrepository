package Day2_Examples;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class OpenGoogle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.google.com");
		driver.manage().window().maximize();
//		driver.findElement(By.id("ten_10")).click();
		sum();
		driver.close();
	}

	private static void sum() {
		// TODO Auto-generated method stub
		System.out.println("Inside of Sum");
	}
}
