package Day2_Examples;

public class ReusableLibrary {

}
