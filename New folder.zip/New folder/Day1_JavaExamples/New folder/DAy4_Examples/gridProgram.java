package DAy4_Examples;

import java.net.MalformedURLException;
import java.net.URL;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

/* 
 * Grid Console - http://localhost:4444/grid/console
 * The default port used by the hub is 4444. 
 * CREATE THIS PROGRAM ON HUB and IT WILL BE RUN ON NODE
 The hub is the central point wherein you load your tests.
 Nodes are the Selenium instances that will execute the tests that you loaded on the hub.
 */
public class gridProgram {

	public static void main(String[] args) throws MalformedURLException {
		// TODO Auto-generated method stub
		String baseURL = "http://www.google.com";
		String nodeURL = "http://192.1.54.2:5566/wd/hub";
		DesiredCapabilities dc = DesiredCapabilities.firefox();
		dc.setBrowserName("firefox");
		dc.setPlatform(Platform.XP);
		WebDriver driver = new RemoteWebDriver(new URL(nodeURL), dc);
		driver.get(baseURL);
		if (driver.getCurrentUrl().contains("google"))
			System.out.println("Opened Google");
		else
			System.out.println("OPening Google FAiled");
	}

}
