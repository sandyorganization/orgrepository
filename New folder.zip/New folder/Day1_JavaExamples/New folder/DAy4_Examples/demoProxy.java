package DAy4_Examples;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

public class demoProxy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String PROXY = "localhost:8080";

		org.openqa.selenium.Proxy proxy = new org.openqa.selenium.Proxy();
		proxy.setHttpProxy(PROXY)
		     .setFtpProxy(PROXY)
		     .setSslProxy(PROXY);
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability(CapabilityType.PROXY, proxy);
		System.setProperty("webdriver.ie.driver", "D:\\Other Supp Files\\IEDriverServer.exe");
		WebDriver driver = new InternetExplorerDriver(cap);
	}

}
