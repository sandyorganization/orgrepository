package Day1_JavaExamples;

public class ImplInterface implements TestInterface {

	public void printValues(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println("The values of a and b are:" + " " + a + " " + b);
	}

	public void multiply(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println("The multiplication of a and b is:" + " " + a * b);
	}

	public void minusOne(int a) {
		// TODO Auto-generated method stub
		System.out.println("The Minus one from a is:" + " " + (a - 1));
	}

}
