package Day1_JavaExamples;

public class demo_Data_types {
static int i=10;
	public static void main(String[] args) {
		int a = 100; // 32 bit storage
		short s = 1; // 16 bit
		long b = 284782471; // 64 bit storage
		double c = 10.632; // 64 bit storage
		boolean d = true; // holds either true or false
		char ch = 'c'; // 16 bit
		// int and long cannot be used to store decimal numbers, so we use
		// double
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		System.out.println(s);
		System.out.println(ch);

		System.out.println("Boolean results for 4>5 and 4<5");
		System.out.println(4 > 5); // it prints false as the statement is wrong
		System.out.println((4 < 5)); // it prints true
	}
}
