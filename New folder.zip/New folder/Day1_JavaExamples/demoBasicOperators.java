package Day1_JavaExamples;

public class demoBasicOperators {

	public static void main(String[] args) {
		int a = 2, b = 3, c = 100, d = 100;

		// Greater Operator

		if (a > b & a > c)
			System.out.println("A is greater of three");
		if (b > a & b > c)
			System.out.println("B is greater of three");
		if (c > b & c > a)
			System.out.println("C is greater of three");

		// + Operator
		System.out.println("Sum of a and b is" + " " + a + b);

		// - Operator
		System.out.println("Deletion of a from b is" + " " + (b - a));

		// * Operator
		System.out.println("Multiplication of a and b is" + " " + a * b);

		// / Operator
		System.out.println("Division of a and b is" + " " + a / b);

		// % Operator
		System.out.println("Modulus of C is" + " " + c % 10);

		// == and != Operators
		if (a == b)
			System.out.println("a == b");
		else if (a != b)
			System.out.println("a!=b");

		// < Operator
		if (a < b)
			System.out.println(a < b);
		else if (c <= d)
			System.out.println(c <= d);
	}
}
