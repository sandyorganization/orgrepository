package Day1_JavaExamples;

public class methOverrSubClass extends methOverrSupClass {
	int Speed = 800;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		methOverrSupClass supObj = new methOverrSupClass(); // Super Class

		int sum1 = supObj.sum(10, 20);
		System.out.println(sum1);
		int sum2 = supObj.sum(10, 20, 30);
		System.out.println(sum2);

		methOverrSubClass subObj = new methOverrSubClass(); // Sub Class Object
		int sum3 = subObj.sum(2, 3);
		System.out.println(sum3);
		subObj.display();

		// Accessing super class method using subclass
		// object - INHERITENCE
		supObj.multi(10, 20);
		System.out.println("Super Class variable accessed using subclass object, because of INHERITENCE" + " " + supObj.Speed);
	}

	public void display() {
		System.out.println(super.Speed); // Super and this which refer to Super
											// class and current objects
		System.out.println(this.Speed);
	}

	public int sum(int a, int b) {
		System.out.println("Inside sub class method");
		return a * b;
	}
}
