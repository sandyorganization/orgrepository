package Day1_JavaExamples;

abstract class Company {
	int empCount = 100000;

	abstract void compName();

	public void addNumbers() {
		int a = 0, b = 0, c;
		c = a + b;
	}
}
