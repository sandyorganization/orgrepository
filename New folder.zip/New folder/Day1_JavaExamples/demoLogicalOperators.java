package Day1_JavaExamples;

public class demoLogicalOperators {

	public static void main(String[] args) {
		int count = 0;

		// conditional AND

		for (int i = 101; i <= 999; i++) {
			String a = Integer.toString(i);
			if ((a.charAt(0) < a.charAt(1)) && a.charAt(1) < a.charAt(2)) {
				System.out.println(a);
				count++;
			}
		}
		System.out.println(count);

		// Conditional OR

		int a = 10, b = 20;
		if (a > 10 || b == 20)
			System.out.println("Logical OR worked");

		// Not

		if (!(a == 10))
			System.out.println("A is not equal to 10");
		else
			System.out.println("A is equal to 10");
	}
}
