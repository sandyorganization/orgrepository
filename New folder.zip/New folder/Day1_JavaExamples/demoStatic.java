package Day1_JavaExamples;

public class demoStatic {
	static int a = 500; // saves memory, gets created on class loading

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int b = 100;
		display1();
		display2();
		System.out.println("Staic variable in Main" + " " + a);
		multiply(b);
		System.out.println(b);
	}

	private static void display1() {
		// TODO Auto-generated method stub
		System.out.println("Static variable before modification" + " " + a);
		a = a * 2;
		System.out.println("Static variable after modification" + " " + a);
	}

	private static void display2() {
		// TODO Auto-generated method stub
		System.out.println("Static variable in a different method" + " " + a);
	}

	public static void multiply(int j) {
		j = j * 2;
		System.out.println(j);
	}
}
// if any object changes the value of the static variable, it will retain its
// value.
