package Day1_JavaExamples;

public class demoMethods {

	public static void main(String[] args) {
		sum(4, 5);
		int max = max(4, 5);
		System.out.println("The maximum of 4 and 5 is" + ":" + max);
		multi(4, 5);
		String ob = new String();
		ob = evenorodd(4);
		System.out.println("Number 4 is" + ":" + ob);
		int sumofevennos = sumofeven(10);
		System.out.println("Sum of even numbers from 1-10 is" + ":" + sumofevennos);
	}

	public static int sumofeven(int n) {
		int sum = 0;
		for (int i = 1; i <= n; i++) {
			if (i % 2 == 0)
				sum = sum + i;
		}
		return (sum);
	}

	private static String evenorodd(int i) {
		if (i % 2 == 0)
			return "Even";
		else
			return "Odd";
	}

	public static void sum(int a, int b) {
		int sum = a + b;
		System.out.println("Sum of 4 and 5 is" + ":" + sum);
	}

	public static int max(int a, int b) {
		if (a > b)
			return (a);
		else
			return (b);
	}

	public static void multi(int a, int b) {
		int multi = a * b;
		System.out.println("Multiplication of 4 and 5 is" + ":" + multi);
	}
}
