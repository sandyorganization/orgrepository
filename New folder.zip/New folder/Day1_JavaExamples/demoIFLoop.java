package Day1_JavaExamples;

public class demoIFLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 1, b = 2, c = 3;
		if (a == b)
			System.out.println("a and b are equal");
		if (a < b)
			System.out.println("a is less than b");
		if (a < c)
			System.out.println("a is less than c");

		int i=10;
		if(i==20)
			System.out.println("In IF STATEMENT");
		else if(i==10)
			System.out.println("IN ELSE IF STATEMENT");
		else
			System.out.println("IN ELSE STATEMENT");
	}
}
