package Day1_JavaExamples;

public class methOverrSupClass {

	int Speed = 500;

	public int sum(int a, int b) {
		System.out.println("Inside Super class method");
		return (a + b);
	}

	public int sum(int a, int b, int c) {
		System.out.println("Inside Super class method");
		return (a + b + c);
	}

	public int multi(int a, int b) {
		System.out.println("Inside Super class method");
		return (a * b);
	}
}
