package Day1_JavaExamples;

public class demoStringObject {

	public static void main(String[] args) throws InterruptedException {
		demoStringObject ob = new demoStringObject();
		ob.Sam();
		ob.Sam1();
		String ob1 = new String();
		ob1 = "Swathi";
		System.out.println(ob1.charAt(2));
	}

	void Sam() {
		System.out.println("My method1");
	}

	void Sam1() {
		System.out.println("My method2");
	}
}
