package Day1_JavaExamples;

public class demo2DArray {

	public static void main(String[] args) {
		int a[][] = new int[3][2];

		// 00 01
		// 10 11
		// 20 21

		a[0][0] = 00;
		a[0][1] = 01;

		a[1][0] = 10;
		a[1][1] = 11;

		a[2][0] = 20;
		a[2][1] = 21;

		int row = a.length;
		int col = a[0].length;

		for (int i = 0; i < row; i++) {

			for (int j = 0; j < col; j++) {

				System.out.println(a[i][j] + " ");
			}
			System.out.println();
		}

	}
}
