package Day1_JavaExamples;

public class demoarray {

	public static void main(String[] args) {
		int a[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }; // Single Dimentional
		System.out.println("Integer array");
		for (int i = 0; i < a.length; i++)
			System.out.println(a[i]);

		// array size is fixed and one type of array cannot accept other data
		// so we use objects
		String str[] = new String[3];
		str[0] = "Swathi";
		str[1] = "Samyuktha";
		str[2] = "Lam";

		System.out.println("String array" + ":" + str[0] + " " + str[1] + " " + str[2]);

		// only integers
		int arr[] = new int[3];
		arr[0] = 10;
		arr[1] = 11;
		arr[2] = 12;
		System.out.println("Integer array object");
		for (int j = 0; j < arr.length; j++)
			System.out.println(arr[j]);

		// So we use objects

		Object ob[] = new Object[3];
		ob[0] = 12;
		ob[1] = "sam";
		ob[2] = 23.23;
		// ob[3]=true;
		System.out.println("Object array");
		for (int j = 0; j < ob.length; j++)
			System.out.println(ob[j]);

	}
}
