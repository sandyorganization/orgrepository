package Day1_JavaExamples;

public class DefConstructor {

	// Constructor does not have a return type and it of the same name as Class

	DefConstructor() {
		System.out.println("Inside def construcor");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DefConstructor ob1 = new DefConstructor();
		ob1.printMsg();
	}

	private void printMsg() {
		// TODO Auto-generated method stub
		System.out.println("Inside printMsg Method");
	}
}
