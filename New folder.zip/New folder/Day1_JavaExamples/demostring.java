package Day1_JavaExamples;

public class demostring {

	public static void main(String[] args) {
		char ch = 'c';
		String s = "Swathi Samyuktha Lam"; // String
		System.out.println(s.length());
		System.out.println(s.charAt(0));
		for (int i = 1; i < s.length(); i++)
			System.out.println(s.charAt(i));

		String str[] = new String[4]; // String Array
		str[0] = "12324";
		str[1] = "sam";
		str[2] = "lam";
		str[3] = "Anil";
		System.out.println("String str values in order:");
		for (int j = 0; j <= str.length; j++)
			System.out.println(str[j]);
	}
}
