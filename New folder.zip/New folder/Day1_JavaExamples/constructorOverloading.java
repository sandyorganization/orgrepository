package Day1_JavaExamples;

public class constructorOverloading {

	public constructorOverloading() {
		System.out.println("Inside default constructor");
	}

	public constructorOverloading(int i) {
		System.out.println("Inside single parameter constructor with int value");
	}

	public constructorOverloading(String str) {
		System.out.println("Inside single parameter constructor with String object");
	}

	public constructorOverloading(int i, int j) {
		System.out.println("Inside double parameter constructor");
	}

	public static void main(String a[]) {
		constructorOverloading mco = new constructorOverloading();
		constructorOverloading spmco = new constructorOverloading(10);
		constructorOverloading dpmco = new constructorOverloading(10, 20);
		constructorOverloading kpmco = new constructorOverloading("java2novice");
	}
}
