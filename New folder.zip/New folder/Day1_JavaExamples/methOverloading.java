package Day1_JavaExamples;

public class methOverloading {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 10, b = 20, c = 30;
		int sum1 = sum(10, 20);
		System.out.println(sum1);
		int sum2 = sum(10, 20, 30);
		System.out.println(sum2);
		double sum3 = sum(10.5, 10);
		System.out.println(sum3);
		// sum(10.5, 10.5);
	}

	private static int sum(int a, int b, int c) {
		// TODO Auto-generated method stub
		return (a + b + c);
	}

	private static int sum(int a, int b) {
		// TODO Auto-generated method stub
		return (a + b);
	}

	private static double sum(double a, int b) {
		// TODO Auto-generated method stub
		return (a + b);
	}
}
